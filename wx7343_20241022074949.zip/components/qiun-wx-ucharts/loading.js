Component({
  properties: {
    loadingType: {
      type: Number,
      value: 2
    }
  },
  observers: {
    'loadingType': function(val) {
    },
  },
  methods: {
  }
})