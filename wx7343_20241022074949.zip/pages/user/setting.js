const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bgpic4:'https://image.meiye.art/Fha6tqRTIwHtlLW3xuZBJj8ZXSX3?imageMogr2/thumbnail/450x/interlace/1',
bgpic25:'https://php2.diyhey.com/uploads/store/comment/20231230/31c0bc033c9ddef199a139675b3cfc13.png',
data32List :[{"name":"孩子管理","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/da4fd99008811ad56293a32a9dc071d4.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/da4fd99008811ad56293a32a9dc071d4.png"},{"name":"订餐管理","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/27ea54d6181fa2ed6ab822e0556ce38d.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/27ea54d6181fa2ed6ab822e0556ce38d.png"},{"name":"退餐管理","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/90d6e730792abe4b15cf1d8967a5abad.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/90d6e730792abe4b15cf1d8967a5abad.png"},{"name":"专属客服","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/e0224508cfa50f3cf45fdfd5699992c1.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/e0224508cfa50f3cf45fdfd5699992c1.png"},{"name":"请假管理","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/6aecc7cae5c73738234e7bc946922ab4.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/6aecc7cae5c73738234e7bc946922ab4.png"},{"name":"专属客服","imgtype":1,"iconcolor":"black","iconname":"cuIcon-home","url":"","pic":"https://php2.diyhey.com//uploads/store/comment/20240515/53795503d349e8c42c9894a2cbad7460.png","desc":"","image":"https://php2.diyhey.com//uploads/store/comment/20240515/53795503d349e8c42c9894a2cbad7460.png"}],
/**vuejs**/
        
    CustomBar: app.globalData.CustomBar

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  
                   goclick30(index,item) {
                         },
})
