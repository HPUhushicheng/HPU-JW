const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    picsrc10:'https://php2.diyhey.com//uploads/store/comment/20240426/dd124474ed7559b499f342d0db8d4dca.png',
picsrc17:'https://php2.diyhey.com//uploads/store/comment/20240426/b3b24391561755735ab198aed6c67b83.png',
picsrc24:'https://php2.diyhey.com//uploads/store/comment/20240426/bda8ea23fa5e3322e86caf2e84922d98.png',
picsrc31:'https://php2.diyhey.com//uploads/store/comment/20240426/932fca4421eeaa985e8eded8f9680c5a.png',
picsrc38:'https://php2.diyhey.com//uploads/store/comment/20240426/dd124474ed7559b499f342d0db8d4dca.png',
picsrc45:'https://php2.diyhey.com//uploads/store/comment/20240426/dd124474ed7559b499f342d0db8d4dca.png',
picsrc52:'https://php2.diyhey.com//uploads/store/comment/20240426/dd124474ed7559b499f342d0db8d4dca.png',
picsrc59:'https://php2.diyhey.com//uploads/store/comment/20240426/dd124474ed7559b499f342d0db8d4dca.png',
picsrc66:'https://php2.diyhey.com//uploads/store/comment/20240426/bda8ea23fa5e3322e86caf2e84922d98.png',
picsrc73:'https://php2.diyhey.com//uploads/store/comment/20240426/932fca4421eeaa985e8eded8f9680c5a.png',
data74List :[{"name":"【广州市】快件已到达地球","iconcolor":"blue","iconname":"cuIcon-noticefill","bgcolor":"red"},{"name":"这是第一次，我家的铲屎官走了这么久。久到足足有三天！！","iconcolor":"black","bgcolor":"green","iconname":"cuIcon-attentionforbidfill"},{"name":"这是第一次，我家的铲屎官走了这么久。","iconcolor":"black","bgcolor":"blue","iconname":"cuIcon-evaluate_fill"}],
/**vuejs**/
        
    CustomBar: app.globalData.CustomBar

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  
                   goclick75(index,item) {
                         },
})
